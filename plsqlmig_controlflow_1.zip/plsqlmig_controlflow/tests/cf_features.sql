CREATE OR REPLACE PACKAGE BODY cf_demo AS
  g_run_id NUMBER := 0;

  FUNCTION fee_rate(p_amt IN NUMBER) RETURN NUMBER IS
  BEGIN
    IF p_amt > 1000 THEN
      RETURN 0.01;
    ELSIF p_amt > 100 THEN
      RETURN 0.02;
    ELSE
      RETURN 0.05;
    END IF;
  END fee_rate;

  PROCEDURE get_total(p_cust IN NUMBER, p_total OUT NUMBER) IS
  BEGIN
    SELECT NVL(SUM(amount), 0) INTO p_total FROM orders WHERE cust_id = p_cust;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_total := 0;
  END get_total;

  PROCEDURE running_balance IS
    CURSOR c_tx IS SELECT tx_id, amount FROM txns ORDER BY tx_id;
    v_bal NUMBER := 0;
  BEGIN
    FOR r IN c_tx LOOP
      v_bal := v_bal + r.amount;
      UPDATE txns SET balance = v_bal WHERE tx_id = r.tx_id;
    END LOOP;
    COMMIT;
  END running_balance;

  PROCEDURE classify_orders IS
    v_total NUMBER;
    v_cnt   NUMBER := 0;
    i       NUMBER;
  BEGIN
    g_run_id := g_run_id + 1;
    get_total(10, v_total);
    IF v_total > 500 THEN
      INSERT INTO order_flags (cust_id, flag, run_id) VALUES (10, 'BIG', g_run_id);
    END IF;
    FOR i IN 1 .. 3 LOOP
      v_cnt := v_cnt + i;
    END LOOP;
    WHILE v_cnt < 10 LOOP
      v_cnt := v_cnt + 1;
    END LOOP;
    IF v_cnt <> 10 THEN
      RAISE_APPLICATION_ERROR(-20001, 'count mismatch ' || v_cnt);
    END IF;
    INSERT INTO order_flags (cust_id, flag, run_id)
      SELECT cust_id, 'RATE' || TO_CHAR(fee_rate(amount)), g_run_id FROM orders WHERE amount > 0;
  END classify_orders;

  PROCEDURE drain_queue IS
    CURSOR c_q IS SELECT q_id, payload FROM work_queue WHERE done = 'N';
    v_id NUMBER;
    v_payload VARCHAR2(100);
  BEGIN
    OPEN c_q;
    LOOP
      FETCH c_q INTO v_id, v_payload;
      EXIT WHEN c_q%NOTFOUND;
      INSERT INTO work_log (q_id, msg) VALUES (v_id, 'done:' || v_payload);
    END LOOP;
    CLOSE c_q;
  END drain_queue;
END cf_demo;
/
