"""End-to-end test of --pyspark-cf-out output on real Spark 4 with seeded data.
UPDATE/DELETE/MERGE: plain Spark tables cannot run them (Delta jars unavailable in this
sandbox), so a *test double* rewrites the table from an equivalent SELECT. Everything else
is real Spark execution of the generated code."""
import sys, importlib.util, datetime as dt, traceback
import sqlglot
from sqlglot import exp
from pyspark.sql import SparkSession

spark = (SparkSession.builder.master("local[2]").appName("cftest")
         .config("spark.ui.enabled", "false").config("spark.sql.warehouse.dir", "/tmp/cfwh")
         .config("spark.sql.ansi.enabled", "true").getOrCreate())
spark.sparkContext.setLogLevel("ERROR")

def ddl(name, cols, rows=()):
    spark.sql(f"DROP TABLE IF EXISTS {name}")
    spark.sql(f"CREATE TABLE {name} ({cols}) USING parquet")
    if rows:
        spark.createDataFrame(list(rows), spark.table(name).schema).write.insertInto(name)

def seed():
    spark.sql("CREATE DATABASE IF NOT EXISTS exttrhst")
    ddl("claims", "claim_id INT, amount DOUBLE, customer_id INT, status STRING, fee DOUBLE, claim_dt DATE, product_id INT, paid_amt DOUBLE",
        [(1, 100.0, 11, "PENDING", None, dt.date(2026, 9, 1), 1, 0.0),
         (2, 60000.0, 12, "PENDING", None, dt.date(2026, 9, 1), 1, 0.0),
         (3, 500.0, 13, "CLOSED", None, dt.date(2026, 9, 1), 1, 450.0),
         (4, 75000.0, 14, "PENDING", None, dt.date(2026, 9, 2), 2, 0.0)])
    ddl("products", "product_id INT, name STRING", [(1, "A"), (2, "B")])
    ddl("claim_summary", "claim_dt DATE, product_id INT, total_paid DOUBLE, claim_count BIGINT")
    ddl("audit_log", "claim_id INT, note STRING")
    ddl("ledger", "claim_id INT, customer_id INT, amount DOUBLE, entry_id BIGINT")
    ddl("invoices", "invoice_id INT, customer_id INT, amount DOUBLE, status STRING, posting_id BIGINT",
        [(101, 21, 5000.0, "NEW", None), (102, 22, 15000.0, "NEW", None), (103, 23, 200.0, "POSTED", 7)])
    ddl("txns", "tx_id INT, amount DOUBLE, balance DOUBLE", [(1, 10.0, None), (2, 20.0, None), (3, -5.0, None)])
    ddl("orders", "order_id INT, cust_id INT, amount DOUBLE, sale_date DATE, region_id INT",
        [(1, 10, 400.0, dt.date(2026, 9, 1), 1), (2, 10, 200.0, dt.date(2026, 9, 1), 2), (3, 20, 50.0, dt.date(2026, 9, 2), 1)])
    ddl("order_flags", "cust_id INT, flag STRING, run_id INT")
    ddl("regions", "region_id INT", [(1,), (2,)])
    ddl("daily_sales_summary", "sale_date DATE, region_id INT, total_amount DOUBLE, order_count BIGINT")
    ddl("region_rollup", "region_id INT, amt DOUBLE", [(1, 1.0)])
    ddl("work_queue", "q_id INT, payload STRING, done STRING", [(1, "a", "N"), (2, "b", "Y"), (3, "c", "N")])
    ddl("work_log", "q_id INT, msg STRING")
    ddl("exttrhst.status", "ID INT, PROCESS STRING, ACTION STRING, STATUS STRING, start_dt TIMESTAMP, end_dt TIMESTAMP")
    ddl("exttrhst.ar_extract_status", "extr_run_dt DATE", [(dt.date(2020, 1, 1),), (dt.date.today(),)])
    ddl("ie_balance", "acct_id INT, bal DOUBLE", [(1, 1.0)])
    ddl("ar_balance", "acct_id INT, bal DOUBLE, asof TIMESTAMP")
    ddl("balances", "acct_id INT, amount DOUBLE", [(1, 5.0), (1, 7.0), (2, 3.0)])

# ---------------------------------------------------------------- test double for row-level DML
DML_EMULATED = []

def _rewrite(table, select_sql, args):
    df = spark.sql(select_sql, args=args or {}).localCheckpoint()
    df.write.mode("overwrite").insertInto(table, overwrite=True)

def emulate(sql, args):
    t = sqlglot.parse_one(sql, read="spark")
    if isinstance(t, exp.Update):
        tbl = t.this.sql("spark"); cols = spark.table(tbl).columns
        sets = {e.this.name.lower(): e.expression.sql("spark") for e in t.expressions}
        where = t.args["where"].this.sql("spark") if t.args.get("where") else "TRUE"
        sel = ", ".join(f"CASE WHEN {where} THEN {sets[c.lower()]} ELSE {c} END AS {c}" if c.lower() in sets else c for c in cols)
        _rewrite(tbl, f"SELECT {sel} FROM {tbl}", args); return "UPDATE"
    if isinstance(t, exp.Delete):
        tbl = t.this.sql("spark"); where = t.args["where"].this.sql("spark")
        _rewrite(tbl, f"SELECT * FROM {tbl} WHERE NOT COALESCE({where}, FALSE)", args); return "DELETE"
    if isinstance(t, exp.Merge):
        tgt = t.this; tname = tgt.this.sql("spark") if isinstance(tgt, exp.Alias) else tgt.sql("spark").split(" AS ")[0]
        talias = tgt.alias or tname
        src = t.args["using"]; salias = src.alias; src_sql = src.this.sql("spark") if isinstance(src, exp.Subquery) else src.sql("spark").split(" AS ")[0]
        if isinstance(src, exp.Subquery): src_sql = f"({src.this.sql('spark')})"
        on = t.args["on"].sql("spark"); cols = spark.table(tname).columns
        upd, delete, ins = {}, False, None
        for w in t.args["whens"].expressions:
            then = w.args["then"]
            if w.args.get("matched"):
                if isinstance(then, exp.Update):
                    upd = {e.this.name.lower(): e.expression.sql("spark") for e in then.expressions}
                else:
                    delete = True
            else:
                ins = then
        sel = ", ".join(f"CASE WHEN {salias}.__hit THEN {upd[c.lower()]} ELSE {talias}.{c} END AS {c}" if c.lower() in upd else f"{talias}.{c}" for c in cols)
        q = (f"SELECT {sel} FROM {tname} AS {talias} LEFT JOIN (SELECT __s.*, TRUE AS __hit FROM {src_sql} AS __s) AS {salias} ON {on}"
             + (f" WHERE {salias}.__hit IS NULL" if delete else ""))
        if ins is not None:
            icols = [c.name for c in ins.this.expressions]; ivals = [v.sql("spark") for v in ins.expression.expressions]
            m = dict(zip([c.lower() for c in icols], ivals))
            isel = ", ".join(m.get(c.lower(), "NULL") for c in cols)
            q += f" UNION ALL SELECT {isel} FROM {src_sql} AS {salias} WHERE NOT EXISTS (SELECT 1 FROM {tname} AS {talias} WHERE {on})"
        _rewrite(tname, q, args); return "MERGE"
    raise RuntimeError("cannot emulate")

def load(path):
    spec = importlib.util.spec_from_file_location("gen", path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    real = m._dml
    def _dml(spark_, sql, args=None):
        try:
            return real(spark_, sql, args)
        except Exception as e:
            if "UNSUPPORTED_FEATURE.TABLE_OPERATION" in str(e):
                DML_EMULATED.append(emulate(sql, args)); return 0
            raise
    m._dml = _dml
    return m

rows = lambda q: [tuple(r) for r in spark.sql(q).collect()]
RESULTS = []
def check(name, fn, expect_fn):
    try:
        fn()
        problems = expect_fn()
        RESULTS.append((name, "PASS" if not problems else "FAIL", problems or ""))
    except Exception as e:
        RESULTS.append((name, "ERROR", str(e).split("\n")[0][:160]))

seed()
cf = load(sys.argv[1]); cf2 = load(sys.argv[2])

# ---- claims_engine.process_pending : cursor loop + nested call + IF  -> set-based
def exp_pending():
    p = []
    fee = dict(rows("SELECT claim_id, fee FROM claims"))
    want = {1: 2.0, 2: 1200.0, 3: None, 4: 1500.0}
    if fee != want: p.append(f"claims.fee {fee} != {want}")
    a = sorted(rows("SELECT claim_id, note FROM audit_log"))
    if a != [(2, "high value"), (4, "high value")]: p.append(f"audit_log {a}")
    l = sorted(rows("SELECT claim_id, customer_id, amount FROM ledger"))
    if l != [(1, 11, 100.0), (2, 12, 60000.0), (4, 14, 75000.0)]: p.append(f"ledger {l}")
    s = rows("SELECT claim_dt, product_id, total_paid, claim_count FROM claim_summary")
    if s != [(dt.date(2026, 9, 1), 1, 450.0, 1)]: p.append(f"claim_summary {s}")
    return "; ".join(p)
check("run_all -> rebuild_summary + process_pending (cursor loop, nested call, IF)", lambda: cf.run_all(), exp_pending)

# ---- sales_etl.post_invoices : sequence per row + UPDATE + INSERT + IF/DBMS_OUTPUT -> set-based
def exp_post():
    p = []
    inv = sorted(rows("SELECT invoice_id, status, posting_id FROM invoices"))
    posted = {i: pid for i, s, pid in inv if i in (101, 102)}
    if any(s != "POSTED" for i, s, _ in inv): p.append(f"status {inv}")
    if len(set(posted.values())) != 2 or None in posted.values(): p.append(f"posting ids not unique {posted}")
    led = {e: (c, a) for _, c, a, e in rows("SELECT * FROM ledger WHERE entry_id IS NOT NULL")}
    if set(led) != set(posted.values()): p.append(f"ledger entry ids {sorted(led)} != posting ids {sorted(posted.values())}")
    return "; ".join(p)
check("post_invoices (NEXTVAL per row, UPDATE+INSERT per row, IF)", lambda: cf.post_invoices(), exp_post)

# ---- sales_etl.load_daily_summary : parameter binding + MERGE
def exp_daily():
    p = []
    d = sorted(rows("SELECT sale_date, region_id, total_amount, order_count FROM daily_sales_summary"))
    if d != [(dt.date(2026, 9, 1), 1, 400.0, 1), (dt.date(2026, 9, 1), 2, 200.0, 1)]: p.append(f"daily {d}")
    r = sorted(rows("SELECT region_id, amt FROM region_rollup"))
    if r != [(1, 400.0), (2, 200.0)]: p.append(f"rollup {r}")
    return "; ".join(p)
check("load_daily_summary(p_run_date) (parameter binding, MERGE)", lambda: cf.load_daily_summary(p_run_date=dt.date(2026, 9, 1)), exp_daily)

# ---- RUN_AR_EXTRACT orchestration: IF/ELSIF, calls, globals, exception handler
def run_extract():
    cf.gextractid = 99
    cf.run_ar_extract(singletable="IE_BALANCE")
def exp_extract():
    p = []
    st = sorted(rows("SELECT ID, ACTION, STATUS, end_dt IS NOT NULL FROM exttrhst.status"), key=str)
    if len(st) != 2 or any(r[0] != 99 or r[2] != "SUCCESS" or not r[3] for r in st): p.append(f"status {st}")
    if rows("SELECT count(*) FROM ie_balance") != [(0,)]: p.append("IE_BALANCE not truncated")
    b = sorted(rows("SELECT acct_id, bal FROM ar_balance"))
    if b != [(1, 12.0), (2, 3.0)]: p.append(f"ar_balance {b}")
    return "; ".join(p)
check("RUN_AR_EXTRACT(singletable='IE_BALANCE') (IF/ELSIF, calls, globals, TRUNCATE)", run_extract, exp_extract)

AR_T = ["AR_ACCOUNT_INFO","AR_CODE_DESC","AR_CONVERSION_RT","AR_CUSTOMER","AR_FACILITY","AR_PRODUCT",
        "AR_RISK_TYPE","AR_RISK_TYPE_MAP","AR_MONITORING_INFO","AR_ACCOUNT_GROUP"]
for t in AR_T:
    spark.sql(f"CREATE TABLE IF NOT EXISTS {t} (x INT) USING parquet")
    spark.sql(f"INSERT INTO {t} VALUES (1)")
def exp_trunc():
    p = []
    r = rows("SELECT count(*) FROM exttrhst.ar_extract_status")
    if r != [(1,)]: p.append(f"expected old row deleted, got {r}")
    for t in AR_T + ["AR_BALANCE"]:
        if rows(f"SELECT count(*) FROM {t}") != [(0,)]: p.append(f"{t} not truncated")
    return "; ".join(p)
check("TruncateTable (DELETE with SYSDATE - 90 -> date_sub, 11 TRUNCATEs)", lambda: cf.truncatetable(), exp_trunc)

# ---- feature package
def exp_running():
    b = sorted(rows("SELECT tx_id, balance FROM txns"))
    return "" if b == [(1, 10.0), (2, 30.0), (3, 25.0)] else f"balances {b}"
check("running_balance (state across rows -> row-by-row fallback)", lambda: cf2.running_balance(), exp_running)

def exp_classify():
    p = []
    f = sorted(rows("SELECT cust_id, flag, run_id FROM order_flags"), key=str)
    want = sorted([(10, "BIG", 1), (10, "RATE0.02", 1), (10, "RATE0.02", 1), (20, "RATE0.05", 1)], key=str)
    if f != want: p.append(f"flags {f} != {want}")
    return "; ".join(p)
check("classify_orders (OUT param, SELECT INTO, FOR/WHILE, RAISE_APPLICATION_ERROR, UDF)", lambda: cf2.classify_orders(), exp_classify)

def exp_drain():
    w = sorted(rows("SELECT q_id, msg FROM work_log"))
    return "" if w == [(1, "done:a"), (3, "done:c")] else f"work_log {w}"
check("drain_queue (OPEN/FETCH/EXIT WHEN %NOTFOUND/CLOSE)", lambda: cf2.drain_queue(), exp_drain)

def exp_fee():
    got = [cf2.fee_rate(p_amt=x) for x in (5000, 500, 50)]
    return "" if got == [0.01, 0.02, 0.05] else f"fee_rate {got}"
check("fee_rate function (IF/ELSIF/ELSE RETURN)", lambda: None, exp_fee)

print("\n=== RESULTS ===")
for n, s, d in RESULTS:
    print(f"[{s}] {n}" + (f"\n        {d}" if d else ""))
print(f"\nrow-level DML emulated (Delta test double): {DML_EMULATED}")
