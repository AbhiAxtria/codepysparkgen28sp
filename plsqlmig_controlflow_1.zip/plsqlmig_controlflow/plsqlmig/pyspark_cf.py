"""
Control-flow PySpark generator  (CLI: --pyspark-cf-out PATH)

The original generator (pyspark_gen.py) reads the *graph* and emits the SQL
statements of each routine. This generator reads the *AST* instead, so it can
translate the procedural logic around the SQL as well:

  PL/SQL                                  ->  PySpark
  ---------------------------------------     ------------------------------------------
  parameters / local variables / constants    Python arguments / locals
  package-level variables                     module-level globals
  := assignments, IF / ELSIF / ELSE           Python assignments, if / elif / else
  WHILE / basic LOOP / numeric FOR / EXIT     while / for range(...) / break
  nested procedures & functions               inner Python functions (closures)
  procedure / function calls, OUT params      Python calls, OUT params returned
  EXCEPTION / WHEN / RAISE / RAISE_APP_ERROR   try / except / raise
  SELECT ... INTO                             _select_into()  (NO_DATA_FOUND/TOO_MANY_ROWS)
  DML with PL/SQL variables                   spark.sql(..., args={...}) named parameters
  EXECUTE IMMEDIATE 'truncate table X'        TRUNCATE TABLE via spark.sql
  COMMIT / ROLLBACK / SAVEPOINT               dropped, with a note (no multi-statement txn)
  sequence.NEXTVAL                            _nextval() helper / row_number() offset
  OPEN / FETCH / CLOSE explicit cursors       _Cursor helper

  FOR rec IN cursor LOOP  (cursor FOR loops)
     * SET-BASED rewrite when the loop body is independent per row: the cursor
       becomes a DataFrame, row-level assignments become derived columns, IF
       conditions become WHERE filters, and each DML statement runs ONCE for all
       rows (INSERT..SELECT, MERGE for UPDATE/DELETE). Nested procedure calls
       made from the loop are inlined when their bodies are simple.
     * ROW-BY-ROW fallback otherwise (state carried across rows, EXIT, nested
       loops, unsupported statements): a Python for-loop over the collected
       rows. Correct but runs on the driver -- flagged for a set-based redesign.

It is additive: it does not change the graph, the verdicts, or pyspark_gen.py.
Output is a strong starting point for developers, not certified-equivalent
code: correctness must still be proven by running against real data
(see --validate-out).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

import sqlglot
from sqlglot import exp

from . import plsql_ast as A
from .graph_model import Graph, nid

PY_KEYWORDS = {"and", "as", "assert", "async", "await", "break", "class", "continue", "def",
               "del", "elif", "else", "except", "finally", "for", "from", "global", "if",
               "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise",
               "return", "try", "while", "with", "yield", "none", "true", "false", "print",
               "spark", "id", "type", "str", "int", "len", "max", "min", "sum", "round"}

EXC_MAP = {"OTHERS": "Exception", "NO_DATA_FOUND": "NoDataFound", "TOO_MANY_ROWS": "TooManyRows",
           "ZERO_DIVIDE": "ZeroDivisionError", "VALUE_ERROR": "ValueError",
           "DUP_VAL_ON_INDEX": "DupValOnIndex", "INVALID_NUMBER": "ValueError",
           "CURSOR_ALREADY_OPEN": "PlsqlError", "INVALID_CURSOR": "PlsqlError"}

PY_FUNCS = {"NVL": "_nvl", "NVL2": "_nvl2", "COALESCE": "_coalesce", "TO_CHAR": "_to_char",
            "TO_NUMBER": "_to_number", "TO_DATE": "_to_date", "SUBSTR": "_substr",
            "UPPER": "_upper", "LOWER": "_lower", "TRIM": "_trim", "LTRIM": "_ltrim",
            "RTRIM": "_rtrim", "LENGTH": "_length", "INSTR": "_instr", "REPLACE": "_replace",
            "ROUND": "_round", "TRUNC": "_trunc", "ABS": "abs", "GREATEST": "_greatest",
            "LEAST": "_least", "MOD": "_mod", "ADD_MONTHS": "_add_months", "DECODE": "_decode",
            "SIGN": "_sign", "CEIL": "_ceil", "FLOOR": "_floor", "LPAD": "_lpad", "RPAD": "_rpad"}


def py_name(n: str) -> str:
    n = re.sub(r"\W", "_", (n or "").strip().lower())
    return n + "_" if n in PY_KEYWORDS else n


# ---------------------------------------------------------------------------
# source-text helpers (cursor queries & loop record names are not kept in the
# AST, so they are recovered from the routine source without touching parser)
# ---------------------------------------------------------------------------
_CURSOR_RE = re.compile(r"(?is)\bCURSOR\s+(\w+)\s*(\((.*?)\))?\s+IS\s+(.*?);")
_FORLOOP_RE = re.compile(r"(?is)\bFOR\s+(\w+)\s+IN\s+(REVERSE\s+)?(.*?)\s+LOOP\b")


def _strip_comments(src: str) -> str:
    src = re.sub(r"/\*.*?\*/", " ", src, flags=re.S)
    return re.sub(r"--[^\n]*", " ", src)


def cursor_defs(src: str) -> Dict[str, Tuple[List[str], str]]:
    out = {}
    for m in _CURSOR_RE.finditer(_strip_comments(src or "")):
        params = []
        if m.group(3):
            for p in m.group(3).split(","):
                p = p.strip()
                if p:
                    params.append(p.split()[0])
        out[m.group(1).lower()] = (params, m.group(4).strip())
    return out


def for_loops(src: str) -> List[Tuple[str, bool, str]]:
    """(record/index var, reverse, iterable text) in source order."""
    return [(m.group(1), bool(m.group(2)), m.group(3).strip())
            for m in _FORLOOP_RE.finditer(_strip_comments(src or ""))]


# ---------------------------------------------------------------------------
# scope
# ---------------------------------------------------------------------------
@dataclass
class Scope:
    locals: Set[str] = field(default_factory=set)        # python names
    params: Set[str] = field(default_factory=set)
    records: Dict[str, str] = field(default_factory=dict)  # plsql rec var -> python expr ("rec")
    cursors: Dict[str, Tuple[List[str], str]] = field(default_factory=dict)
    parent: Optional["Scope"] = None
    assigned: Set[str] = field(default_factory=set)       # names assigned in this function
    is_function: bool = False

    def lookup(self, name: str) -> Optional[str]:
        n = name.lower()
        s = self
        while s:
            if n in s.records:
                return "record"
            if py_name(n) in s.locals or py_name(n) in s.params:
                return "var"
            s = s.parent
        return None

    def owner(self, name: str) -> Optional["Scope"]:
        s = self
        while s:
            if py_name(name) in s.locals or py_name(name) in s.params:
                return s
            s = s.parent
        return None

    def rec(self, name: str) -> str:
        s = self
        while s:
            if name.lower() in s.records:
                return s.records[name.lower()]
            s = s.parent
        return py_name(name)

    def cursor(self, name: str):
        s = self
        while s:
            if name.lower() in s.cursors:
                return s.cursors[name.lower()]
            s = s.parent
        return None

    def all_vars(self) -> Set[str]:
        out, s = set(), self
        while s:
            out |= s.locals | s.params
            s = s.parent
        return out


# ---------------------------------------------------------------------------
# the generator
# ---------------------------------------------------------------------------
def spark_ddl(sql: str, table_format: str = "delta") -> str:
    """Oracle CREATE TABLE / CTAS / VIEW -> Spark SQL (types mapped, IF NOT EXISTS,
    USING <format> so MERGE/UPDATE/DELETE work later). Returns '' if unparseable."""
    sql = sql.strip().rstrip(";").strip()
    try:
        t = sqlglot.parse_one(sql, read="oracle")
    except Exception:
        return ""
    if isinstance(t, exp.Create) and (t.args.get("kind") or "").upper() == "TABLE":
        if not t.expression:                      # plain column-list table, not CTAS
            t.set("exists", True)
        # drop Oracle storage clauses (TABLESPACE, PCTFREE, ...) and set the format
        t.set("properties", exp.Properties(expressions=[exp.FileFormatProperty(this=exp.Var(this=table_format.upper()))]))
    # Oracle NUMBER with no precision is arbitrary precision; Spark's bare DECIMAL
    # means DECIMAL(10,0) and would truncate -- use DECIMAL(38,10) instead.
    for dt in t.find_all(exp.DataType):
        if dt.this == exp.DataType.Type.DECIMAL and not dt.expressions:
            dt.set("expressions", [exp.DataTypeParam(this=exp.Literal.number(38)),
                                   exp.DataTypeParam(this=exp.Literal.number(10))])
    out = t.sql(dialect="spark")
    return out.replace(f"STORED AS {table_format.upper()}", f"USING {table_format}")


class CFGen:
    def __init__(self, corpus, g: Optional[Graph] = None, include_all: bool = False):
        self.corpus = corpus
        self.g = g
        self.include_all = include_all
        self.out: List[str] = []
        self.globals: Set[str] = set()
        self.routines: Dict[str, Tuple[A.Routine, str]] = {}   # lower name/qual -> (routine, pyname)
        self.decision: Dict[str, dict] = {}
        self.stats = {"routines": 0, "loops_set_based": 0, "loops_row_by_row": 0,
                      "todos": 0, "skipped": 0}
        self.todo_notes: List[str] = []
        self._seq = 0
        self._pending_binds: Dict[str, str] = {}
        self.nested: Set[int] = set()
        self.pkg_globals: Dict[str, str] = {}
        self.sql_functions: Dict[str, A.Routine] = {}
        self._collect()

    # -------------------------------------------------------------- setup
    def _collect(self):
        used_py: Dict[str, int] = {}
        for _path, nodes in self.corpus:
            for node in nodes:
                if isinstance(node, A.Package):
                    for m in node.members:
                        if isinstance(m, A.Decl) and m.kind in ("VARIABLE", "CONSTANT"):
                            self.globals.add(py_name(m.name))
                            self.pkg_globals[py_name(m.name)] = self._pkg_default(node.source, m.name)
                        elif isinstance(m, A.Routine) and not m.is_forward:
                            self._register(m, f"{node.name}.{m.name}", node.name, used_py)
                elif isinstance(node, A.Routine) and not node.is_forward:
                    self._register(node, node.name, "", used_py)
        # verdicts from the knowledge graph (if supplied)
        if self.g is not None:
            for e in self.g.edges:
                if e.rel == "ASSESSED_AS":
                    self.decision[e.src] = self.g.nodes[e.dst].props
        # identifiers used inside INSERT ... VALUES (...) can only be variables, never
        # columns: any that are not declared locally are package/global variables
        # declared outside the parsed corpus (e.g. a package spec that was not supplied)
        self.external_globals: Set[str] = set()
        for _path, nodes in self.corpus:
            for node in nodes:
                rs = [node] if isinstance(node, A.Routine) else \
                     [m for m in getattr(node, "members", []) if isinstance(m, A.Routine)]
                for r in rs:
                    self._scan_values_vars(r, set())
        # undeclared identifiers assigned anywhere -> treated as package/global state
        for _path, nodes in self.corpus:
            for node in nodes:
                rs = [node] if isinstance(node, A.Routine) else \
                     [m for m in getattr(node, "members", []) if isinstance(m, A.Routine)]
                for r in rs:
                    self._scan_globals(r, set())

    def _register(self, r: A.Routine, qual: str, pkg: str, used_py: Dict[str, int]):
        base = py_name(r.name)
        if base in used_py:
            base = py_name(f"{pkg}_{r.name}") if pkg else f"{base}_{used_py[base]}"
        used_py[base] = used_py.get(base, 0) + 1
        self.routines[qual.lower()] = (r, base)
        self.routines.setdefault(r.name.lower(), (r, base))
        self._register_nested(r, qual)

    def _register_nested(self, r: A.Routine, qual: str):
        for d in r.decls:
            if isinstance(d, A.Routine) and not d.is_forward:
                self.nested.add(id(d))
                self.routines.setdefault(f"{qual}.{d.name}".lower(), (d, py_name(d.name)))
                self.routines.setdefault(d.name.lower(), (d, py_name(d.name)))
                self._register_nested(d, f"{qual}.{d.name}")

    def _pkg_default(self, src: str, name: str) -> str:
        head = re.split(r"(?i)\b(PROCEDURE|FUNCTION)\b", _strip_comments(src or ""), 1)[0]
        m = re.search(rf"(?is)\b{re.escape(name)}\s+(?:CONSTANT\s+)?[A-Za-z][\w.%()\s,]*?(?::=|\bDEFAULT\b)\s*(.*?);", head)
        if not m:
            return "None"
        try:
            return self._expr_py(_norm_ops(m.group(1)), Scope())
        except _Unsupported:
            return "None  # TODO: default " + m.group(1).strip()[:50]

    def _scan_values_vars(self, r: A.Routine, outer: Set[str]):
        local = {p.name.lower() for p in r.params} | outer | \
                {d.name.lower() for d in r.decls if isinstance(d, A.Decl)}
        for d in r.decls:
            if isinstance(d, A.Routine):
                self._scan_values_vars(d, local)

        def walk(stmts):
            for s in stmts:
                if isinstance(s, A.SqlStmt) and s.kind == "INSERT" and re.search(r"(?i)\bVALUES\b", s.text):
                    try:
                        t = sqlglot.parse_one(s.text.strip().rstrip(";"), read="oracle")
                    except Exception:
                        continue
                    for v in t.find_all(exp.Values):
                        for c in v.find_all(exp.Column):
                            if not c.table and c.name.lower() not in local \
                                    and py_name(c.name) not in self.pkg_globals \
                                    and c.name.upper() not in ("SYSDATE", "SYSTIMESTAMP", "USER"):
                                self.globals.add(py_name(c.name))
                                self.external_globals.add(py_name(c.name))
                if isinstance(s, A.IfStmt):
                    for _c, b in s.branches:
                        walk(b)
                elif hasattr(s, "body") and isinstance(getattr(s, "body"), list):
                    walk(s.body)
        walk(r.body)

    def _scan_globals(self, r: A.Routine, outer: Set[str]):
        local = {py_name(p.name) for p in r.params} | outer | \
                {py_name(d.name) for d in r.decls if isinstance(d, A.Decl)}
        for d in r.decls:
            if isinstance(d, A.Routine):
                self._scan_globals(d, local)

        def walk(stmts):
            for s in stmts:
                if isinstance(s, A.AssignStmt):
                    t = s.target.split(".")[0]
                    if py_name(t) not in local:
                        self.globals.add(py_name(t))
                for attr in ("body",):
                    if hasattr(s, attr) and isinstance(getattr(s, attr), list):
                        walk(getattr(s, attr))
                if isinstance(s, A.IfStmt):
                    for _c, b in s.branches:
                        walk(b)
                if isinstance(s, A.Block):
                    for h in s.handlers:
                        walk(h.body)
        walk(r.body)
        for h in r.handlers:
            walk(h.body)

    # -------------------------------------------------------------- output
    def w(self, ind: int, line: str = ""):
        self.out.append(("    " * ind + line) if line else "")

    def todo(self, ind: int, msg: str):
        self.stats["todos"] += 1
        self.w(ind, f"# TODO: {msg}")

    # -------------------------------------------------------------- SQL
    def _sql_bind(self, text: str, scope: Scope, rec_mode: str = "python",
                  target_alias: Optional[str] = None) -> Tuple[str, Dict[str, str], List[str]]:
        """Transpile Oracle SQL to Spark SQL and replace PL/SQL variable references.

        rec_mode='python': vars/records -> :named parameters (values bound at run time)
        rec_mode='set'   : records & row-level vars -> _r.<col>; other vars -> :params
        Returns (spark_sql, {param: python_expr}, notes)."""
        notes: List[str] = []
        txt = text.strip().rstrip(";")
        txt = re.sub(r"(?i)\b(\w+)\.(NEXTVAL|CURRVAL)\b", lambda m: f"__seq_{m.group(2).lower()}__{m.group(1).lower()}", txt)
        try:
            tree = sqlglot.parse_one(txt, read="oracle")
        except Exception:
            notes.append("SQL could not be parsed by sqlglot; left as-is")
            return txt, {}, notes
        binds: Dict[str, str] = {}
        for c in list(tree.find_all(exp.Column)):
            name = c.name
            tbl = c.table
            low = name.lower()
            if low.startswith("__seq_"):
                kind, seq = low[6:].split("__", 1)
                if rec_mode == "set":
                    pn = f"seqbase_{py_name(seq)}"
                    binds[pn] = f"_seq_reserve('{seq}', _n)"
                    c.replace(sqlglot.parse_one(
                        f"(:{pn} + row_number() OVER (ORDER BY monotonically_increasing_id()))", read="spark"))
                elif isinstance(tree, exp.Insert) and not isinstance(tree.expression, exp.Values):
                    pn = f"seqbase_{py_name(seq)}"
                    binds[pn] = f"_seq_reserve('{seq}', 1000000)"
                    c.replace(sqlglot.parse_one(
                        f"(:{pn} + row_number() OVER (ORDER BY monotonically_increasing_id()))", read="spark"))
                    notes.append("multi-row INSERT..SELECT with NEXTVAL: keys = reserved block + row_number()")
                else:
                    pn = f"seq_{py_name(seq)}"
                    binds[pn] = f"_{kind}('{seq}')"
                    c.replace(exp.Placeholder(this=pn))
                notes.append(f"sequence {seq}.{kind.upper()} replaced (not gap-free like Oracle)")
                continue
            if tbl and scope.lookup(tbl) == "record":
                if rec_mode == "set":
                    c.replace(exp.column(low, table="_r"))
                else:
                    pn = f"{py_name(tbl)}__{py_name(name)}"
                    binds[pn] = f"{scope.rec(tbl)}['{low}']"
                    c.replace(exp.Placeholder(this=pn))
                continue
            if not tbl and scope.lookup(name) == "var":
                if rec_mode == "set" and hasattr(scope, "rowvars") and low in scope.rowvars:
                    c.replace(exp.column(scope.rowvars[low], table="_r"))
                    continue
                pn = py_name(name)
                binds[pn] = pn
                c.replace(exp.Placeholder(this=pn))
                continue
            if not tbl and py_name(name) in self.globals:
                pn = py_name(name)
                binds[pn] = pn
                c.replace(exp.Placeholder(this=pn))
                continue
            if target_alias and not tbl:
                c.set("table", exp.to_identifier(target_alias))
        for f in list(tree.find_all(exp.Anonymous)):
            fname = str(f.this).lower()
            tgt = self.routines.get(fname)
            if tgt and tgt[0].kind == "FUNCTION":
                self.sql_functions[tgt[1]] = tgt[0]
                notes.append(f"PL/SQL function {tgt[0].name} called from SQL -> registered as a Spark UDF (row-at-a-time)")
        spark_sql = tree.sql(dialect="spark")
        # Oracle date arithmetic: SYSDATE +/- n  ->  date_add/date_sub
        spark_sql, k = re.subn(r"(CURRENT_TIMESTAMP\(\)|CURRENT_DATE\(\)?)\s*-\s*(\d+(?:\.\d+)?)",
                               r"date_sub(current_date(), \2)", spark_sql)
        spark_sql, k2 = re.subn(r"(CURRENT_TIMESTAMP\(\)|CURRENT_DATE\(\)?)\s*\+\s*(\d+(?:\.\d+)?)",
                                r"date_add(current_date(), \2)", spark_sql)
        if k or k2:
            notes.append("Oracle date arithmetic (SYSDATE +/- n) mapped to date_add/date_sub (day precision)")
        if "@" in spark_sql:
            notes.append("database link (@dblink) needs a JDBC read/write")
        return spark_sql, binds, notes

    @staticmethod
    def _args(binds: Dict[str, str]) -> str:
        if not binds:
            return ""
        return ", args={" + ", ".join(f"'{k}': {v}" for k, v in binds.items()) + "}"

    # -------------------------------------------------------------- expressions
    _TOK = re.compile(r"""\s*(?:
          (?P<str>'(?:[^']|'')*')
        | (?P<num>\d+(?:\.\d+)?)
        | (?P<op>:=|=>|<>|!=|\^=|>=|<=|\|\||\.\.|[-+*/(),=<>])
        | (?P<id>[A-Za-z_][\w$#]*(?:\s*\.\s*[A-Za-z_][\w$#]*)*(?:%\w+)?)
        )""", re.X)

    def expr(self, text: str, scope: Scope) -> str:
        """Translate a PL/SQL expression/condition to Python; falls back to Spark SQL eval."""
        t = _norm_ops(text.strip().rstrip(";"))
        try:
            return self._expr_py(t, scope)
        except _Unsupported:
            sql, binds, _ = self._sql_bind(f"SELECT {t} FROM dual", scope)
            sql = re.sub(r"(?i)\s+FROM\s+dual\s*$", "", sql)
            self.stats["todos"] += 0
            return f"_eval(spark, {sql!r}{self._args(binds)})"

    def _expr_py(self, t: str, scope: Scope) -> str:
        toks, pos = [], 0
        while pos < len(t):
            m = self._TOK.match(t, pos)
            if not m or m.end() == pos:
                if t[pos:].strip() == "":
                    break
                raise _Unsupported(t)
            pos = m.end()
            kind = m.lastgroup
            toks.append((kind, m.group(kind)))
        # handle || at top level via _cat
        parts, depth, cur = [], 0, []
        for k, v in toks:
            if v == "(":
                depth += 1
            elif v == ")":
                depth -= 1
            if v == "||" and depth == 0:
                parts.append(cur); cur = []
            else:
                cur.append((k, v))
        parts.append(cur)
        if len(parts) > 1:
            return "_cat(" + ", ".join(self._toks_py(p, scope) for p in parts) + ")"
        return self._toks_py(toks, scope)

    def _toks_py(self, toks, scope: Scope) -> str:
        out: List[str] = []
        i = 0
        while i < len(toks):
            k, v = toks[i]
            up = v.upper() if k == "id" else v
            nxt = toks[i + 1][1] if i + 1 < len(toks) else None
            if k == "str":
                out.append(repr(v[1:-1].replace("''", "'")))
            elif k == "num":
                out.append(v)
            elif k == "op":
                if "||" in v:
                    raise _Unsupported(v)
                out.append({"=": "==", "<>": "!=", "^=": "!=", ":=": "=", "=>": "="}.get(v, v))
            else:
                v2 = re.sub(r"\s*\.\s*", ".", v)
                up = v2.upper()
                if up in ("CASE", "WHEN", "THEN", "END", "IN", "BETWEEN", "LIKE", "EXISTS", "SELECT", "CAST"):
                    raise _Unsupported(v2)
                if up == "IS":
                    if i + 2 < len(toks) and toks[i + 1][1].upper() == "NOT" and toks[i + 2][1].upper() == "NULL":
                        out.append("is not None"); i += 3; continue
                    if nxt and nxt.upper() == "NULL":
                        out.append("is None"); i += 2; continue
                    raise _Unsupported(v2)
                simple = {"AND": "and", "OR": "or", "NOT": "not", "NULL": "None", "TRUE": "True",
                          "FALSE": "False", "SYSDATE": "_sysdate()", "SYSTIMESTAMP": "_sysdate()",
                          "SQLERRM": "_sqlerrm(_e)", "SQLCODE": "_sqlcode(_e)"}
                if up in simple:
                    out.append(simple[up])
                elif "%" in v2:
                    base, attr = v2.split("%", 1)
                    attr = attr.upper()
                    if base.upper() == "SQL":
                        out.append({"ROWCOUNT": "_SQL.rowcount", "FOUND": "(_SQL.rowcount > 0)",
                                    "NOTFOUND": "(_SQL.rowcount == 0)"}.get(attr, "None"))
                    else:
                        out.append(f"{py_name(base)}_cur.{attr.lower()}")
                elif re.search(r"(?i)\.(NEXTVAL|CURRVAL)$", v2):
                    seq, kind = v2.rsplit(".", 1)
                    out.append(f"_{kind.lower()}('{seq.lower()}')")
                elif nxt == "(":
                    # function call
                    if up in PY_FUNCS:
                        out.append(PY_FUNCS[up])
                    elif up.lower() in self.routines:
                        out.append(self.routines[up.lower()][1])
                    elif v2.split(".")[-1].lower() in self.routines:
                        out.append(self.routines[v2.split(".")[-1].lower()][1])
                    else:
                        out.append(f"_external({v2!r}).call")
                else:
                    if "." in v2:
                        base, fld = v2.split(".", 1)
                        if scope.lookup(base) == "record":
                            out.append(f"{scope.rec(base)}['{fld.lower()}']")
                        elif up.lower() in self.routines:
                            out.append(f"{self.routines[up.lower()][1]}()")
                        else:
                            out.append(py_name(v2.replace(".", "_")))
                    else:
                        low = v2.lower()
                        if scope.lookup(low) or py_name(low) in self.globals:
                            out.append(py_name(low))
                        elif low in self.routines:
                            out.append(f"{self.routines[low][1]}()")      # parameterless function
                        else:
                            out.append(py_name(low))
            i += 1
        s = " ".join(out)
        s = re.sub(r"\s*\(\s*", "(", s).replace(" )", ")").replace(" ,", ",")
        s = re.sub(r"(\w)\(", r"\1(", s)
        return s

    # -------------------------------------------------------------- routines
    def _ddl_section(self):
        tables, alters, views, other = [], {}, [], []
        for _path, nodes in self.corpus:
            for node in nodes:
                if type(node).__name__ != "DDLObject":
                    continue
                k = (node.kind or "").upper()
                if k == "TABLE":
                    tables.append(node)
                elif k == "ALTER_TABLE":
                    alters.setdefault(node.name.lower(), []).append(node.text)
                elif k == "VIEW":
                    views.append(node)
                else:
                    other.append(node)
        if not (tables or views or other):
            return
        self.w(0, "# ---------------------------------------------------------------- tables / views")
        self.w(0, "# From the CREATE TABLE / VIEW DDL in the parsed files. Oracle types are mapped")
        self.w(0, "# to Spark types; tables are Delta so the MERGE/UPDATE/DELETE below can run.")
        self.w(0, "def create_tables(*, spark=None):")
        self.w(1, '"""Create target tables and views (IF NOT EXISTS). Run once before the procedures."""')
        self.w(1, "spark = spark or _session()")
        for t in tables:
            ddl = spark_ddl(t.text)
            if ddl:
                self.w(1, f"spark.sql({ddl!r})")
            else:
                self.todo(1, f"CREATE TABLE {t.name} could not be transpiled -- write it by hand")
            for a in alters.get(t.name.lower(), []):
                m = re.search(r"(?is)\bADD\s*\((.*)\)\s*;?\s*$", a)
                if m:
                    try:
                        cols = sqlglot.parse_one(f"CREATE TABLE _x ({m.group(1)})", read="oracle").sql(dialect="spark")
                        cols = cols[cols.index("(") + 1:cols.rindex(")")]
                        self.w(1, f"spark.sql({('ALTER TABLE ' + t.name + ' ADD COLUMNS (' + cols + ')')!r})  # from ALTER TABLE ... ADD")
                        continue
                    except Exception:
                        pass
                self.todo(1, f"ALTER TABLE {t.name}: {' '.join(a.split())[:100]}")
        for v in views:
            ddl = spark_ddl(v.text)
            if ddl:
                self.w(1, f"spark.sql({ddl!r})")
            else:
                self.todo(1, f"VIEW {v.name} could not be transpiled")
        for o in other:
            k = (o.kind or "").upper()
            note = {"SEQUENCE": "sequence -> _nextval() helper / identity column",
                    "INDEX": "index -> not needed in Spark (use partitioning / Z-ORDER)",
                    "SYNONYM": "synonym -> reference the real table name / a view",
                    "DATABASE_LINK": "database link -> JDBC read/write"}.get(k, "no Spark equivalent")
            self.w(1, f"# {k} {o.name}: {note}")
        self.w(0, "")
        self.stats["tables"] = len(tables)

    def generate(self) -> str:
        self._header()
        self._ddl_section()
        for _path, nodes in self.corpus:
            for node in nodes:
                if isinstance(node, A.Package):
                    for m in node.members:
                        if isinstance(m, A.Routine) and not m.is_forward:
                            self._top(m, f"{node.name}.{m.name}", node.name)
                elif isinstance(node, A.Routine) and not node.is_forward:
                    self._top(node, node.name, "")
        if self.sql_functions:
            self.w(0, "# ---------------------------------------------------------------- UDFs")
            self.w(0, "# PL/SQL functions referenced inside SQL statements. UDFs run row-at-a-time;")
            self.w(0, "# for volume, re-express the function as a SQL CASE/expression or a join.")
            tmap = {"NUMBER": "double", "INTEGER": "long", "PLS_INTEGER": "long", "BINARY_INTEGER": "long",
                    "VARCHAR2": "string", "VARCHAR": "string", "CHAR": "string", "DATE": "timestamp",
                    "TIMESTAMP": "timestamp", "BOOLEAN": "boolean"}
            for pyn, r in self.sql_functions.items():
                rt = tmap.get((r.return_type or "").split("(")[0].strip().upper(), "string")
                queries = any(isinstance(x, A.SqlStmt) for x in r.body)
                if queries:
                    self.todo(0, f"{r.name} queries tables -- cannot run inside a UDF; rewrite as a join")
                conv = "float(_v)" if rt == "double" else ("int(_v)" if rt == "long" else "_v")
                self.w(0, f"def _udf_{pyn}(*a):")
                self.w(1, f"_v = {pyn}(*a)")
                self.w(1, f"return None if _v is None else {conv}")
                self.w(0, f"spark.udf.register({r.name.lower()!r}, _udf_{pyn}, {rt!r})")
                self.w(0, "")
        self.w(0, "# " + "-" * 74)
        self.w(0, f"# conversion summary: {self.stats}")
        return "\n".join(self.out) + "\n"

    def _verdict(self, qual: str, owner: str, name: str) -> dict:
        if self.g is None:
            return {}
        return self.decision.get(nid("routine", qual.lower()), {})

    def _top(self, r: A.Routine, qual: str, pkg: str):
        v = self._verdict(qual, pkg, r.name)
        decision = v.get("decision", "UNASSESSED")
        if not self.include_all and self.g is not None and \
                decision not in ("CONVERT_TO_PYSPARK", "REWRITE_FOR_PYSPARK"):
            self.stats["skipped"] += 1
            return
        self.stats["routines"] += 1
        self._routine(r, qual, 0, None, v)

    def _routine(self, r: A.Routine, qual: str, ind: int, parent: Optional[Scope], v: dict):
        pyn = self.routines.get(qual.lower(), (r, py_name(r.name)))[1] if parent is None else py_name(r.name)
        scope = Scope(parent=parent, is_function=(r.kind == "FUNCTION"))
        scope.params = {py_name(p.name) for p in r.params}
        scope.cursors = cursor_defs(r.source)
        outs = [py_name(p.name) for p in r.params if "OUT" in (p.mode or "").upper()]
        sig = ", ".join(f"{py_name(p.name)}=None" for p in r.params)
        sig = (sig + ", " if sig else "") + ("*, spark=None" if parent is None else "")
        self.w(ind, f"def {pyn}({sig.rstrip(', ')}):")
        doc = f"{r.kind.title()} {qual}"
        if v:
            doc += f"  |  verdict: {v.get('decision')}  confidence: {v.get('confidence')}  logic: {v.get('logic_pattern')}"
        self.w(ind + 1, f'"""{doc}"""')
        if v.get("decision") == "KEEP_IN_ORACLE":
            self.w(ind + 1, "# WARNING: verdict is KEEP_IN_ORACLE -- converted for completeness/reference.")
            if v.get("blocking"):
                self.w(ind + 1, f"#   blocking constructs (no Spark equivalent): {v['blocking']}")
        # declarations
        for d in r.decls:
            if isinstance(d, A.Decl):
                if d.kind in ("VARIABLE", "CONSTANT"):
                    scope.locals.add(py_name(d.name))
                elif d.kind == "PRAGMA" and "AUTONOMOUS" in d.name.upper():
                    self.w(ind + 1, "# NOTE: PRAGMA AUTONOMOUS_TRANSACTION dropped -- Spark has no independent transactions")
        # globals / nonlocals needed
        assigned = self._assigned_names(r)
        g_needed = sorted(n for n in assigned if n in self.globals and
                          not (n in scope.locals or n in scope.params) and scope.owner(n) is None)
        if g_needed:
            self.w(ind + 1, f"global {', '.join(g_needed)}")
        if parent is None:
            self.w(ind + 1, "spark = spark or _session()")
        if parent is not None:
            nl = sorted(n for n in assigned if n not in scope.locals and n not in scope.params
                        and parent.owner(n) is not None)
            if nl:
                self.w(ind + 1, f"nonlocal {', '.join(nl)}")
        for d in r.decls:
            if isinstance(d, A.Decl) and d.kind in ("VARIABLE", "CONSTANT"):
                init = self._decl_default(r.source, d.name, scope)
                self.w(ind + 1, f"{py_name(d.name)} = {init}")
            elif isinstance(d, A.Decl) and d.kind == "CURSOR":
                self.w(ind + 1, f"# cursor {d.name}: {' '.join((scope.cursor(d.name) or ([], '?'))[1].split())[:110]}")
        # nested routines as closures
        for d in r.decls:
            if isinstance(d, A.Routine) and not d.is_forward:
                nq = f"{qual}.{d.name}"
                nv = self._verdict(nq, qual, d.name)
                self._routine(d, nq, ind + 1, scope, nv)
        own_src = r.source or ""
        for d in r.decls:
            if isinstance(d, A.Routine) and d.source:
                own_src = own_src.replace(d.source, " ")
        self.for_queue = for_loops(own_src)
        body_ind = ind + 1
        if r.handlers:
            self.w(ind + 1, "try:")
            body_ind = ind + 2
        start = len(self.out)
        self._stmts(r.body, body_ind, scope)
        if len(self.out) == start:
            self.w(body_ind, "pass")
        if r.handlers:
            self._handlers(r.handlers, ind + 1, scope)
        if outs:
            self.w(ind + 1, f"return ({', '.join(outs)},)" if len(outs) > 1 else f"return {outs[0]}")
        self.w(ind, "")

    def _decl_default(self, src: str, name: str, scope: Scope) -> str:
        decl = _strip_comments(src or "")
        m0 = re.search(r"(?is)\b(IS|AS)\b(.*?)\bBEGIN\b", decl)
        decl = m0.group(2) if m0 else ""
        m = re.search(rf"(?is)(?:^|;)\s*{re.escape(name)}\s+(?:CONSTANT\s+)?[A-Za-z][\w.%()\s,]*?(?::=|\bDEFAULT\b)\s*(.*?);",
                      decl)
        if m:
            try:
                return self._expr_py(m.group(1), scope)
            except _Unsupported:
                return "None  # TODO: default value " + m.group(1).strip()[:60]
        return "None"

    def _assigned_names(self, r: A.Routine) -> Set[str]:
        names: Set[str] = set()

        def walk(stmts):
            for s in stmts:
                if isinstance(s, A.AssignStmt):
                    names.add(py_name(s.target.split(".")[0]))
                elif isinstance(s, A.SqlStmt) and s.kind == "SELECT":
                    m = re.search(r"(?is)\bINTO\s+(.*?)\s+FROM\b", s.text)
                    if m:
                        names.update(py_name(x.strip()) for x in m.group(1).split(","))
                if isinstance(s, A.IfStmt):
                    for _c, b in s.branches:
                        walk(b)
                elif hasattr(s, "body") and isinstance(getattr(s, "body"), list):
                    walk(s.body)
                if isinstance(s, A.Block):
                    for h in s.handlers:
                        walk(h.body)
        walk(r.body)
        for h in r.handlers:
            walk(h.body)
        return names

    # -------------------------------------------------------------- statements
    def _stmts(self, stmts, ind: int, scope: Scope):
        for s in stmts:
            self._stmt(s, ind, scope)

    def _stmt(self, s, ind: int, scope: Scope):
        if isinstance(s, A.AssignStmt):
            rhs = s.text.split(":=", 1)[1] if ":=" in s.text else ""
            tgt = s.target
            if "." in tgt and scope.lookup(tgt.split(".")[0]) == "record":
                b, f = tgt.split(".", 1)
                lhs = f"{scope.rec(b)}['{f.lower()}']"
            else:
                lhs = py_name(tgt)
            self.w(ind, f"{lhs} = {self.expr(rhs, scope)}")
        elif isinstance(s, A.SqlStmt):
            self._sql_stmt(s, ind, scope)
        elif isinstance(s, A.ExecImmediate):
            m = re.match(r"(?is)EXECUTE\s+IMMEDIATE\s+'(.*)'\s*;?$", s.text.strip())
            if m and "'" not in m.group(1):
                sql = m.group(1).strip()
                if re.match(r"(?i)truncate\s+table", sql):
                    self.w(ind, f"spark.sql({('TRUNCATE TABLE ' + sql.split()[-1])!r})")
                elif re.match(r"(?i)create\s+(global\s+temporary\s+)?table|create\s+(or\s+replace\s+)?view", sql) and spark_ddl(sql):
                    if re.match(r"(?i)create\s+global\s+temporary", sql):
                        self.w(ind, "# NOTE: GLOBAL TEMPORARY TABLE -> consider a temp view / cached DataFrame instead")
                    self.w(ind, f"spark.sql({spark_ddl(sql)!r})")
                else:
                    self.w(ind, f"spark.sql({sql!r})")
            else:
                body = re.sub(r"(?is)^EXECUTE\s+IMMEDIATE\s+", "", s.text.strip()).rstrip(";")
                body = re.split(r"(?i)\s+USING\s+", body)[0]
                self.todo(ind, "dynamic SQL -- confirm the generated statement is valid Spark SQL")
                self.w(ind, f"spark.sql(str({self.expr(body, scope)}))")
        elif isinstance(s, A.CallStmt):
            self._call(s, ind, scope)
        elif isinstance(s, A.SimpleStmt):
            self._simple(s, ind, scope)
        elif isinstance(s, A.IfStmt):
            first = True
            for cond, body in s.branches:
                if cond.strip().upper() == "ELSE":
                    self.w(ind, "else:")
                else:
                    self.w(ind, f"{'if' if first else 'elif'} {self.expr(cond, scope)}:")
                start = len(self.out)
                self._stmts(body, ind + 1, scope)
                if len(self.out) == start:
                    self.w(ind + 1, "pass")
                first = False
        elif isinstance(s, A.LoopStmt):
            self._loop(s, ind, scope)
        elif isinstance(s, A.Block):
            inner = Scope(parent=scope, locals={py_name(d.name) for d in s.decls if isinstance(d, A.Decl)})
            for d in s.decls:
                if isinstance(d, A.Decl) and d.kind in ("VARIABLE", "CONSTANT"):
                    self.w(ind, f"{py_name(d.name)} = None")
            if s.handlers:
                self.w(ind, "try:")
                self._stmts(s.body, ind + 1, scope)
                self._handlers(s.handlers, ind, scope)
            else:
                self._stmts(s.body, ind, scope)
        elif isinstance(s, A.CaseStmt):
            self.todo(ind, f"CASE statement -- translate branches manually: {' '.join(s.text.split())[:90]}")
            self.w(ind, "raise NotImplementedError('CASE statement not auto-converted')")
        else:
            self.todo(ind, f"unsupported statement {type(s).__name__}")

    def _sql_stmt(self, s: A.SqlStmt, ind: int, scope: Scope):
        text = s.text.strip().rstrip(";")
        if s.kind == "SELECT":
            m = re.search(r"(?is)^(SELECT\s+.*?)\s+(BULK\s+COLLECT\s+)?INTO\s+(.*?)\s+(FROM\b.*)$", text)
            if m:
                targets = [x.strip() for x in m.group(3).split(",")]
                sql, binds, notes = self._sql_bind(f"{m.group(1)} {m.group(4)}", scope)
                for n in notes:
                    self.w(ind, f"# NOTE: {n}")
                lhs = ", ".join(py_name(t) for t in targets)
                if m.group(2):
                    self.w(ind, f"{lhs} = _bulk_collect(spark, {sql!r}{self._args(binds)})")
                else:
                    fn = "_select_into" if len(targets) > 1 else "_select_into_one"
                    self.w(ind, f"{lhs}{',' if len(targets) > 1 else ''} = {fn}(spark, {sql!r}{self._args(binds)})"
                           .replace(",, =", ", ="))
                return
        sql, binds, notes = self._sql_bind(text, scope)
        for n in notes:
            self.w(ind, f"# NOTE: {n}")
        if s.kind in ("UPDATE", "DELETE", "MERGE"):
            self.w(ind, "# NOTE: UPDATE/DELETE/MERGE need a transactional table format (Delta/Iceberg)")
        self.w(ind, f"_SQL.rowcount = _dml(spark, {sql!r}{self._args(binds)})")

    def _call(self, s: A.CallStmt, ind: int, scope: Scope):
        callee = s.callee
        up = callee.upper()
        args_txt = ""
        m = re.search(r"\((.*)\)\s*;?\s*$", s.text, re.S)
        if m:
            args_txt = m.group(1)
        args = _split_args(args_txt)
        if up == "RAISE_APPLICATION_ERROR":
            py = ", ".join(self.expr(a, scope) for a in args[:2])
            self.w(ind, f"raise PlsqlError({py})")
            return
        if up.startswith("DBMS_OUTPUT."):
            self.w(ind, f"print({', '.join(self.expr(a, scope) for a in args)})")
            return
        if up.startswith("DBMS_STATS.") or up.startswith("DBMS_LOCK.") or up.startswith("DBMS_APPLICATION_INFO."):
            self.w(ind, f"pass  # {callee}: Oracle housekeeping, not needed in Spark")
            return
        key = callee.lower()
        target = self.routines.get(key) or self.routines.get(key.split(".")[-1])
        if target is None or up.startswith(("DBMS_", "UTL_")):
            self.todo(ind, f"external call {callee} -- not in the parsed corpus")
            py_args = ", ".join(self.expr(a, scope) for a in args)
            self.w(ind, f"_external({callee!r}).call({py_args})")
            return
        routine, pyn = target
        if scope.parent is not None or any(pyn == py_name(d.name) for d in []):
            pass
        pos, kw, outs = [], [], []
        params = routine.params
        for i, a in enumerate(args):
            if "=>" in a:
                k, val = a.split("=>", 1)
                pname = k.strip()
                p = next((p for p in params if p.name.lower() == pname.lower()), None)
                if p and "OUT" in (p.mode or "").upper():
                    outs.append(self.expr(val, scope))
                if p is None or "IN" in (p.mode or "IN").upper().replace("OUT", "") or (p.mode or "").upper() == "IN OUT":
                    kw.append(f"{py_name(pname)}={self.expr(val, scope)}")
            else:
                p = params[i] if i < len(params) else None
                mode = (p.mode if p else "IN").upper()
                if "OUT" in mode:
                    outs.append(self.expr(a, scope))
                if mode != "OUT":
                    if p:
                        kw.append(f"{py_name(p.name)}={self.expr(a, scope)}")
                    else:
                        pos.append(self.expr(a, scope))
        call = f"{pyn}({', '.join(pos + kw)})"
        in_nested = self._is_nested_name(pyn, scope)
        if not in_nested and not self._is_generated(routine, key):
            self.w(ind, f"# NOTE: {callee} is not converted in this run (verdict) -- runs in Oracle via the pipeline driver")
        if outs:
            self.w(ind, f"{', '.join(outs)} = {call}")
        else:
            self.w(ind, call)

    def _is_nested_name(self, pyn: str, scope: Scope) -> bool:
        return False

    def _is_generated(self, routine: A.Routine, key: str) -> bool:
        if self.include_all or self.g is None or id(routine) in self.nested:
            return True
        for qual, (r, _p) in self.routines.items():
            if r is routine:
                d = self.decision.get(nid("routine", qual), {}).get("decision")
                if d in ("CONVERT_TO_PYSPARK", "REWRITE_FOR_PYSPARK"):
                    return True
        return False

    def _simple(self, s: A.SimpleStmt, ind: int, scope: Scope):
        kw = s.keyword.upper()
        text = s.text.strip().rstrip(";")
        if kw == "COMMIT":
            self.w(ind, "pass  # COMMIT: each Spark write is committed on its own")
        elif kw == "ROLLBACK":
            self.w(ind, "pass  # ROLLBACK: no multi-statement rollback in Spark -- use idempotent writes / Delta RESTORE")
        elif kw == "SAVEPOINT":
            self.w(ind, "pass  # SAVEPOINT: not supported in Spark")
        elif kw == "NULL":
            self.w(ind, "pass")
        elif kw == "RETURN":
            rest = text[6:].strip()
            self.w(ind, f"return {self.expr(rest, scope)}" if rest else "return")
        elif kw == "RAISE":
            name = text[5:].strip()
            if not name:
                self.w(ind, "raise")
            else:
                self.w(ind, f"raise {EXC_MAP.get(name.upper(), 'PlsqlError')}({name!r})")
        elif kw in ("EXIT", "CONTINUE"):
            m = re.search(r"(?is)\bWHEN\s+(.*)$", text)
            stmt = "break" if kw == "EXIT" else "continue"
            if m:
                self.w(ind, f"if {self.expr(m.group(1), scope)}:")
                self.w(ind + 1, stmt)
            else:
                self.w(ind, stmt)
        elif kw == "OPEN":
            cname = (s.arg or text.split()[1]).split("(")[0]
            cur = scope.cursor(cname)
            if cur is None:
                self.todo(ind, f"OPEN {cname}: cursor query not found")
                return
            params, q = cur
            m = re.search(r"\((.*)\)", text)
            argv = _split_args(m.group(1)) if m else []
            sub = Scope(parent=scope, params={py_name(p) for p in params})
            sql, binds, notes = self._sql_bind(q, sub)
            for p, a in zip(params, argv):
                binds[py_name(p)] = self.expr(a, scope)
            self.w(ind, f"{py_name(cname)}_cur = _Cursor(spark, {sql!r}{self._args(binds)})")
        elif kw == "FETCH":
            m = re.search(r"(?is)FETCH\s+(\w+)\s+(BULK\s+COLLECT\s+)?INTO\s+(.*)$", text)
            if m:
                tg = [py_name(x.strip()) for x in m.group(3).split(",")]
                self.w(ind, f"{', '.join(tg)}{',' if len(tg) > 1 else ''} = {py_name(m.group(1))}_cur.fetch({len(tg)})"
                       .replace(",, =", ", ="))
            else:
                self.todo(ind, f"FETCH not understood: {text[:80]}")
        elif kw == "CLOSE":
            self.w(ind, f"{py_name((s.arg or text.split()[1]))}_cur.close()")
        else:
            self.todo(ind, f"statement not converted: {text[:90]}")

    def _handlers(self, handlers, ind: int, scope: Scope):
        for h in handlers:
            names = [n.strip() for n in re.split(r"(?i)\s+OR\s+", h.when)]
            excs = [EXC_MAP.get(n.upper(), py_name(n)) for n in names]
            if "Exception" in excs:
                self.w(ind, "except Exception as _e:")
            else:
                self.w(ind, f"except ({', '.join(excs)},) as _e:")
            start = len(self.out)
            self._stmts(h.body, ind + 1, scope)
            if len(self.out) == start:
                self.w(ind + 1, "pass")

    # -------------------------------------------------------------- loops
    def _next_for(self, s: A.LoopStmt) -> Tuple[str, bool, str]:
        q = getattr(self, "for_queue", [])
        for i, (var, rev, it) in enumerate(q):
            if s.cursor_ref and it.split("(")[0].strip().lower() == s.cursor_ref.lower():
                return q.pop(i)
            if not s.cursor_ref and " ".join(it.split())[:40].lower() == " ".join(s.iter_text.split())[:40].lower():
                return q.pop(i)
        return q.pop(0) if q else ("rec", False, s.iter_text)

    def _loop(self, s: A.LoopStmt, ind: int, scope: Scope):
        if s.loop_kind == "WHILE":
            self.w(ind, f"while {self.expr(s.iter_text, scope)}:")
            self._loop_body(s.body, ind + 1, scope)
            return
        if s.loop_kind == "BASIC":
            self.w(ind, "while True:")
            self._loop_body(s.body, ind + 1, scope)
            return
        var, rev, it = self._next_for(s)
        rng = re.match(r"(?s)(.*?)\s*\.\.\s*(.*)$", it)
        if rng and not re.match(r"(?is)\s*\(?\s*SELECT", it):
            lo, hi = self.expr(rng.group(1), scope), self.expr(rng.group(2), scope)
            inner = Scope(parent=scope, locals={py_name(var)})
            r = f"range({hi}, {lo} - 1, -1)" if rev else f"range({lo}, {hi} + 1)"
            self.w(ind, f"for {py_name(var)} in {r}:")
            self._loop_body(s.body, ind + 1, inner)
            return
        # cursor FOR loop
        if re.match(r"(?is)\s*\(\s*SELECT", it):
            query, cparams, cargs = it.strip()[1:-1], [], []
        else:
            cname = it.split("(")[0].strip()
            cur = scope.cursor(cname)
            if cur is None:
                self.todo(ind, f"cursor {cname} definition not found -- loop left as a stub")
                self.w(ind, "for _ in []:  # cursor query unknown")
                self._loop_body(s.body, ind + 1, scope)
                return
            cparams, query = cur
            m = re.search(r"\((.*)\)", it)
            cargs = _split_args(m.group(1)) if m else []
        inner = Scope(parent=scope, records={var.lower(): py_name(var)})
        csub = Scope(parent=scope, params={py_name(p) for p in cparams})
        qsql, qbinds, qnotes = self._sql_bind(query, csub)
        for p, a in zip(cparams, cargs):
            qbinds[py_name(p)] = self.expr(a, scope)
        plan = self._setbased_plan(s.body, inner, var)
        if plan is not None:
            self._emit_setbased(plan, qsql, qbinds, qnotes, ind, var)
        else:
            self.stats["loops_row_by_row"] += 1
            self.w(ind, f"# ROW-BY-ROW: loop not independent per row ({self._why}) -- runs on the driver; "
                        "redesign as set-based for volume")
            self.w(ind, f"for {py_name(var)} in _rows(spark, {qsql!r}{self._args(qbinds)}):")
            self._loop_body(s.body, ind + 1, inner)

    def _loop_body(self, body, ind, scope):
        start = len(self.out)
        self._stmts(body, ind, scope)
        if len(self.out) == start:
            self.w(ind, "pass")

    # ---- set-based rewrite of a cursor FOR loop --------------------------------
    def _setbased_plan(self, body, scope: Scope, var: str):
        """Return a list of actions if the loop body is independent per row, else None."""
        self._why = ""
        actions: List[tuple] = []
        rowvars: Dict[str, str] = {}
        scope.rowvars = rowvars          # type: ignore[attr-defined]
        ok = self._plan_stmts(body, scope, [], actions, rowvars, depth=0)
        return actions if ok else None

    def _plan_stmts(self, stmts, scope, conds, actions, rowvars, depth) -> bool:
        for st in stmts:
            if not self._plan_stmt(st, scope, conds, actions, rowvars, depth):
                return False
        return True

    def _plan_stmt(self, st, scope, conds, actions, rowvars, depth) -> bool:
        if isinstance(st, A.SimpleStmt):
            k = st.keyword.upper()
            if k in ("COMMIT", "NULL"):
                return True
            self._why = f"{k} inside the loop"
            return False
        if isinstance(st, A.AssignStmt):
            tgt = st.target.lower()
            rhs = st.text.split(":=", 1)[1].strip().rstrip(";")
            if re.search(rf"(?i)\b{re.escape(tgt)}\b", rhs):
                self._why = f"'{tgt}' carries state across rows"
                return False
            sql = self._set_expr(rhs, scope)
            if sql is None:
                return False
            self._seq += 1
            col = f"_v_{py_name(tgt)}_{self._seq}"
            actions.append(("derive", col, sql, list(conds)))
            rowvars[tgt] = col
            return True
        if isinstance(st, A.IfStmt):
            prev: List[str] = []
            for cond, body in st.branches:
                if cond.strip().upper() == "ELSE":
                    c = " AND ".join(f"NOT ({p})" for p in prev) if prev else "TRUE"
                else:
                    cs = self._set_expr(cond, scope)
                    if cs is None:
                        return False
                    c = " AND ".join([f"NOT ({p})" for p in prev] + [f"({cs})"])
                    prev.append(cs)
                if not self._plan_stmts(body, scope, conds + [c], actions, rowvars, depth):
                    return False
            return True
        if isinstance(st, A.SqlStmt):
            if st.kind not in ("INSERT", "UPDATE", "DELETE"):
                self._why = f"{st.kind} inside the loop"
                return False
            act = self._set_dml(st, scope, conds)
            if act is None:
                return False
            actions.append(act)
            return True
        if isinstance(st, A.CallStmt):
            up = st.callee.upper()
            m = re.search(r"\((.*)\)\s*;?\s*$", st.text, re.S)
            args = _split_args(m.group(1)) if m else []
            if up == "DBMS_OUTPUT.PUT_LINE":
                e = self._set_expr(args[0] if args else "''", scope)
                if e is None:
                    return False
                actions.append(("log", e, list(conds)))
                return True
            target = self.routines.get(st.callee.lower()) or self.routines.get(st.callee.lower().split(".")[-1])
            if target is None or depth > 2:
                self._why = f"call to {st.callee} cannot be inlined"
                return False
            routine = target[0]
            if routine.handlers or any(isinstance(d, A.Routine) for d in routine.decls):
                self._why = f"call to {st.callee} has its own exception handling/nesting"
                return False
            # inline: bind callee params to argument expressions (as row-level columns)
            for p, a in zip(routine.params, args):
                e = self._set_expr(a, scope)
                if e is None:
                    return False
                self._seq += 1
                col = f"_p_{py_name(p.name)}_{self._seq}"
                actions.append(("derive", col, e, list(conds)))
                rowvars[p.name.lower()] = col
            saved_params = set(scope.params)
            scope.params |= {py_name(p.name) for p in routine.params}
            ok = self._plan_stmts(routine.body, scope, conds, actions, rowvars, depth + 1)
            scope.params = saved_params
            return ok
        self._why = f"{type(st).__name__} inside the loop"
        return False

    def _set_expr(self, text: str, scope: Scope) -> Optional[str]:
        """PL/SQL expression -> Spark SQL expression over the loop row alias _r."""
        t = _norm_ops(re.sub(r"\s*\.\s*", ".", text.strip().rstrip(";")))
        sql, binds, notes = self._sql_bind(f"SELECT {t} FROM dual", scope, rec_mode="set")
        if sql.upper().startswith("SELECT ") is False:
            self._why = f"expression not understood: {t[:40]}"
            return None
        sql = re.sub(r"(?is)^SELECT\s+", "", sql)
        sql = re.sub(r"(?is)\s+FROM\s+dual\s*$", "", sql)
        self._pending_binds.update(binds)
        return sql

    def _set_dml(self, st: A.SqlStmt, scope: Scope, conds: List[str]):
        text = st.text.strip().rstrip(";")
        where = " AND ".join(conds) if conds else "TRUE"
        if st.kind == "INSERT":
            m = re.match(r"(?is)^INSERT\s+INTO\s+([\w.$#]+)\s*(\(.*?\))?\s*VALUES\s*\((.*)\)\s*$", text)
            if not m:
                self._why = "INSERT ... SELECT inside the loop"
                return None
            table, cols, vals = m.group(1), m.group(2) or "", m.group(3)
            exprs = []
            for v in _split_args(vals):
                e = self._set_expr(v, scope)
                if e is None:
                    return None
                exprs.append(e)
            return ("insert", table, cols, exprs, where)
        if st.kind in ("UPDATE", "DELETE"):
            m = re.match(r"(?is)^(UPDATE\s+([\w.$#]+)(?:\s+(\w+))?\s+SET\s+(.*?)|DELETE\s+FROM\s+([\w.$#]+)(?:\s+(\w+))?)\s+WHERE\s+(.*)$", text)
            if not m:
                self._why = f"{st.kind} without a WHERE clause inside the loop"
                return None
            table = m.group(2) or m.group(5)
            pred = m.group(7)
            if not re.search(r"(?i)\b(" + "|".join(map(re.escape, list(scope.records) + list(scope.rowvars) +
                                                          [p for p in scope.all_vars()])) + r")\b", pred):
                self._why = f"{st.kind} predicate does not depend on the loop row"
                return None
            ps, pb, _ = self._sql_bind(f"SELECT 1 FROM {table} WHERE {pred}", scope, rec_mode="set", target_alias="_t")
            self._pending_binds.update(pb)
            pred_sql = re.sub(r"(?is)^SELECT 1 FROM\s+\S+\s+WHERE\s+", "", ps)
            if st.kind == "DELETE":
                return ("delete", table, pred_sql, where)
            sets = []
            for a in _split_args(m.group(4)):
                if "=" not in a:
                    self._why = "UPDATE SET not understood"
                    return None
                col, rhs = a.split("=", 1)
                e = self._set_expr(rhs, scope)
                if e is None:
                    return None
                sets.append((col.strip().split(".")[-1], e))
            return ("update", table, pred_sql, sets, where)
        return None

    def _emit_setbased(self, actions, qsql, qbinds, qnotes, ind, var):
        self.stats["loops_set_based"] += 1
        binds = dict(qbinds)
        binds.update(self._pending_binds)
        self._pending_binds = {}
        self.w(ind, f"# SET-BASED rewrite of 'FOR {var} IN ... LOOP' (assumes each row is processed independently;")
        self.w(ind, "#   statements run once for all rows, in order, instead of interleaved per row)")
        for n in qnotes:
            self.w(ind, f"# NOTE: {n}")
        self.w(ind, f"_loop = spark.sql({qsql!r}{self._args(qbinds)}).localCheckpoint()  "
                    "# snapshot, like Oracle read consistency")
        self.w(ind, "_loop.createOrReplaceTempView('_loop_rec')")
        needs_n = any("seqbase_" in k for k in binds)
        if needs_n:
            self.w(ind, "_n = _loop.count()")
            for k in list(binds):
                if k.startswith("seqbase_"):
                    self.w(ind, f"_{k} = {binds[k]}")
                    binds[k] = f"_{k}"

        def a_(sql=None):
            return self._args({k: v for k, v in binds.items() if sql is None or f":{k}" in sql})
        for act in actions:
            kind = act[0]
            if kind == "derive":
                _, col, e, conds = act
                c = " AND ".join(conds)
                ex = f"CASE WHEN {c} THEN {e} END" if conds else e
                dsql = 'SELECT _r.*, ' + ex + ' AS ' + col + ' FROM _loop_rec AS _r'
                self.w(ind, f"spark.sql({dsql!r}{a_(dsql)})"
                            f".localCheckpoint().createOrReplaceTempView('_loop_rec')")
            elif kind == "insert":
                _, table, cols, exprs, where = act
                sql = f"INSERT INTO {table} {cols} SELECT {', '.join(exprs)} FROM _loop_rec AS _r WHERE {where}"
                sql = ' '.join(sql.split())
                self.w(ind, f"_dml(spark, {sql!r}{a_(sql)})")
            elif kind == "update":
                _, table, pred, sets, where = act
                sset = ", ".join(f"_t.{c} = {e}" for c, e in sets)
                sql = (f"MERGE INTO {table} AS _t USING (SELECT * FROM _loop_rec AS _r WHERE {where}) AS _r "
                       f"ON {pred} WHEN MATCHED THEN UPDATE SET {sset}")
                self.w(ind, "# UPDATE per row -> MERGE (needs Delta/Iceberg; fails if one target row matches many loop rows)")
                self.w(ind, f"_dml(spark, {sql!r}{a_(sql)})")
            elif kind == "delete":
                _, table, pred, where = act
                sql = (f"MERGE INTO {table} AS _t USING (SELECT * FROM _loop_rec AS _r WHERE {where}) AS _r "
                       f"ON {pred} WHEN MATCHED THEN DELETE")
                self.w(ind, "# DELETE per row -> MERGE ... DELETE (needs Delta/Iceberg)")
                self.w(ind, f"_dml(spark, {sql!r}{a_(sql)})")
            elif kind == "log":
                _, e, conds = act
                c = " AND ".join(conds) if conds else "TRUE"
                sql = f"SELECT {e} AS msg FROM _loop_rec AS _r WHERE {c}"
                self.w(ind, f"for _m in spark.sql({sql!r}{a_(sql)}).limit(1000).collect():  # DBMS_OUTPUT")
                self.w(ind + 1, "print(_m.msg)")

    # -------------------------------------------------------------- header
    def _header(self):
        self.out += HEADER.splitlines()
        if self.globals:
            self.w(0, "# package-level / global PL/SQL variables")
            for gname in sorted(self.globals):
                note = "  # TODO: declared outside the parsed code (package spec?) -- set before running" \
                    if gname in getattr(self, "external_globals", set()) else ""
                self.w(0, f"{gname} = {self.pkg_globals.get(gname, 'None')}{note}")
            self.w(0, "")


class _Unsupported(Exception):
    pass


def _norm_ops(t: str) -> str:
    """Re-join operators the tokenizer split with spaces (e.g. '< >' -> '<>')."""
    for a, b in (("<\\s+>", "<>"), (">\\s+=", ">="), ("<\\s+=", "<="), ("!\\s+=", "!="),
                 (":\\s+=", ":="), ("\\|\\s+\\|", "||"), ("=\\s+>", "=>"), ("\\^\\s+=", "^=")):
        t = re.sub(a, b, t)
    t = re.sub(r"(?<![\w)])-\s+(\d)", r"-\1", t)
    return t


def _split_args(s: str) -> List[str]:
    out, depth, cur, q = [], 0, [], False
    for ch in s or "":
        if ch == "'":
            q = not q
        if not q:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "," and depth == 0:
                out.append("".join(cur).strip()); cur = []; continue
        cur.append(ch)
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return out


HEADER = '''"""
Generated by plsqlmig --pyspark-cf-out (control-flow conversion).
Procedural logic (variables, IF, loops, calls, exceptions) is translated; cursor
FOR loops are rewritten set-based where each row is independent. Review every
TODO / NOTE, then validate against Oracle output before use.
"""
import datetime as _dt
import decimal as _dec
import math as _math
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder.appName("plsql_migration_cf").enableHiveSupport().getOrCreate()


def _session():
    """Active SparkSession on the driver; None inside a UDF on an executor.
    (Functions take spark=None rather than spark=spark so they stay picklable
    when registered as UDFs.)"""
    try:
        return SparkSession.getActiveSession()
    except Exception:
        return None


# ---------------------------------------------------------------- runtime helpers
class PlsqlError(Exception):
    """RAISE_APPLICATION_ERROR / user-defined exception."""


class NoDataFound(PlsqlError):
    pass


class TooManyRows(PlsqlError):
    pass


class DupValOnIndex(PlsqlError):
    pass


class _SQLState:
    rowcount = 0


_SQL = _SQLState()
_SEQ = {}


def _dml(spark, sql, args=None):
    """Run a DML statement; return affected rows when the table format reports it."""
    rows = spark.sql(sql, args=args or {}).collect()
    try:
        return int(rows[0][0]) if rows and rows[0] and isinstance(rows[0][0], int) else 0
    except Exception:
        return 0


def _rows(spark, sql, args=None):
    """Cursor rows as dicts with lower-case keys (row-by-row fallback; driver-side)."""
    return [{k.lower(): v for k, v in r.asDict().items()} for r in spark.sql(sql, args=args or {}).collect()]


def _select_into(spark, sql, args=None):
    rows = spark.sql(sql, args=args or {}).limit(2).collect()
    if not rows:
        raise NoDataFound("NO_DATA_FOUND")
    if len(rows) > 1:
        raise TooManyRows("TOO_MANY_ROWS")
    return tuple(rows[0])


def _select_into_one(spark, sql, args=None):
    return _select_into(spark, sql, args)[0]


def _bulk_collect(spark, sql, args=None):
    rows = spark.sql(sql, args=args or {}).collect()
    return [r[0] for r in rows] if rows and len(rows[0]) == 1 else [tuple(r) for r in rows]


def _eval(spark, expr_sql, args=None):
    """Evaluate a scalar expression in Spark SQL (fallback for complex PL/SQL expressions)."""
    return spark.sql(expr_sql, args=args or {}).collect()[0][0]


class _Cursor:
    def __init__(self, spark, sql, args=None):
        self._it = iter(spark.sql(sql, args=args or {}).collect())
        self.rowcount, self.notfound, self.found, self.isopen = 0, False, False, True

    def fetch(self, n=1):
        r = next(self._it, None)
        self.notfound, self.found = r is None, r is not None
        if r is None:
            return tuple([None] * n) if n > 1 else None
        self.rowcount += 1
        return tuple(r) if n > 1 else ({k.lower(): v for k, v in r.asDict().items()} if len(r) > 1 else r[0])

    def close(self):
        self.isopen = False


class _external:
    """Call to a routine outside the parsed corpus: register an implementation in _EXTERNAL."""
    def __init__(self, name):
        self.name = name

    def call(self, *a, **k):
        impl = _EXTERNAL.get(self.name.lower())
        if impl is None:
            print(f"WARNING: external routine {self.name} not implemented -- skipped")
            return None
        return impl(*a, **k)


_EXTERNAL = {}


def _nextval(seq):
    _SEQ[seq] = _SEQ.get(seq, 0) + 1   # TODO: seed from Oracle sequence / use a key table
    return _SEQ[seq]


def _currval(seq):
    return _SEQ.get(seq)


def _seq_reserve(seq, n):
    base = _SEQ.get(seq, 0)
    _SEQ[seq] = base + n
    return base


def _sysdate():
    return _dt.datetime.now()


def _sqlerrm(e):
    return str(e) if e is not None else "ORA-0000: normal, successful completion"


def _sqlcode(e):
    return -20000 if isinstance(e, PlsqlError) else (-1 if e is not None else 0)


def _cat(*parts):
    return "".join("" if p is None else str(p) for p in parts)


def _nvl(a, b):
    return b if a is None or a == "" else a


def _nvl2(a, b, c):
    return c if a is None or a == "" else b


def _coalesce(*a):
    return next((x for x in a if x is not None and x != ""), None)


def _to_char(v, fmt=None):
    if v is None:
        return None
    if isinstance(v, (_dt.date, _dt.datetime)) and fmt:
        f = (fmt.upper().replace("YYYY", "%Y").replace("MM", "%m").replace("DD", "%d")
             .replace("HH24", "%H").replace("MI", "%M").replace("SS", "%S"))
        return v.strftime(f)
    return str(v)


def _to_number(v, fmt=None):
    return None if v is None or v == "" else _dec.Decimal(str(v))


def _to_date(v, fmt=None):
    if v is None or isinstance(v, (_dt.date, _dt.datetime)):
        return v
    f = (fmt or "YYYY-MM-DD").upper().replace("YYYY", "%Y").replace("MM", "%m").replace("DD", "%d") \\
        .replace("HH24", "%H").replace("MI", "%M").replace("SS", "%S")
    return _dt.datetime.strptime(str(v), f)


def _substr(s, pos, n=None):
    if s is None:
        return None
    s = str(s)
    start = pos - 1 if pos > 0 else len(s) + pos
    return s[start:] if n is None else s[start:start + n]


def _upper(s): return None if s is None else str(s).upper()
def _lower(s): return None if s is None else str(s).lower()
def _trim(s): return None if s is None else str(s).strip()
def _ltrim(s): return None if s is None else str(s).lstrip()
def _rtrim(s): return None if s is None else str(s).rstrip()
def _length(s): return None if s is None or s == "" else len(str(s))
def _instr(s, sub): return 0 if s is None else str(s).find(sub) + 1
def _replace(s, a, b=""): return None if s is None else str(s).replace(a, b or "")
def _round(v, n=0): return None if v is None else round(_dec.Decimal(str(v)), n)
def _trunc(v, n=0):
    if v is None:
        return None
    if isinstance(v, _dt.datetime):
        return v.replace(hour=0, minute=0, second=0, microsecond=0)
    q = _dec.Decimal(1).scaleb(-n)
    return _dec.Decimal(str(v)).quantize(q, rounding=_dec.ROUND_DOWN)
def _greatest(*a): return None if any(x is None for x in a) else max(a)
def _least(*a): return None if any(x is None for x in a) else min(a)
def _mod(a, b): return None if a is None or b is None else (a if b == 0 else a % b)
def _sign(v): return None if v is None else (v > 0) - (v < 0)
def _ceil(v): return None if v is None else _math.ceil(v)
def _floor(v): return None if v is None else _math.floor(v)
def _lpad(s, n, p=" "): return None if s is None else str(s).rjust(n, p)[:n]
def _rpad(s, n, p=" "): return None if s is None else str(s).ljust(n, p)[:n]


def _add_months(d, n):
    if d is None:
        return None
    m = d.month - 1 + int(n)
    y, m = d.year + m // 12, m % 12 + 1
    import calendar
    return d.replace(year=y, month=m, day=min(d.day, calendar.monthrange(y, m)[1]))


def _decode(v, *pairs):
    it = list(pairs)
    for i in range(0, len(it) - 1, 2):
        if v == it[i] or (v is None and it[i] is None):
            return it[i + 1]
    return it[-1] if len(it) % 2 else None


# ---------------------------------------------------------------- converted routines
'''


def generate_pyspark_cf(corpus, g: Optional[Graph] = None, include_all: bool = False) -> Tuple[str, dict]:
    """Return (python source, stats) for the control-flow conversion."""
    gen = CFGen(corpus, g, include_all=include_all)
    gen._pending_binds = {}
    src = gen.generate()
    return src, gen.stats
